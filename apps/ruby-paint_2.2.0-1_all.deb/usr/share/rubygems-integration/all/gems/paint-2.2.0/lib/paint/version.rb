# frozen_string_literal: true

module Paint
  VERSION = "2.2.0"
end
